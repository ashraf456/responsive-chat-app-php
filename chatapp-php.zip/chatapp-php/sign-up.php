<?php 
include 'db.php';
include 'header.php';
 ?>
			<div class="form-body">
				<h1>Sign Up</h1>
				    <p>Please fill in this form to create an account.</p>
				<form action="index.php" method="post">
					<div class="form-group">
					    <label for="username"><b>User Name</b></label>
					    <input type="text" placeholder="eg: ashraf11" name="username" class="form-control" required>
					</div>
					<div class="form-group">
					    <label for="email"><b>Email</b></label>
					    <input type="email" placeholder="Enter Email" name="email" class="form-control" required>
					</div>
					<div class="form-group">
					    <label for="password"><b>Password</b></label>
					    <input type="password" placeholder="Enter Password" name="password" class="form-control" required>
					</div>
					<div class="form-group">
					    <label for="country"><b>Country Name</b></label>
					    <input type="text" placeholder="Country Name" name="country" class="form-control" required>
					</div>
					<!--<div class="form-group">
					    <label for="image"><b>Your Image</b></label>
					    <input type="file"	 name="image" class="form-control" required>
					</div>-->
				    <div class="form-group">
					    <label>
					      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
					    </label>
				    </div>
				    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

				    <div class="clearfix">
				      <button type="submit" name="submit" class="btn btn-success">Sign Up</button>
				      <button type="button" class="btn btn-danger"><a href="">Cancel</a></button>
				    </div>
				  </div>
				</form>
			</div>
		</div>
	</div>
</div>

</body>
</html>

</body>
</html>