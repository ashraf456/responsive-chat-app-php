<?php 
session_start();
include 'header.php';
include 'db.php';
?>
<?php
$username =$_SESSION['username'];
$message = $_POST['message'];
$sql = "INSERT INTO chat(username,message)";
$sql .= "VALUES('$username','$message')";
$result=$conn->query($sql);
     header("Location:chatroom.php");
?>