<!DOCTYPE html>
<html>
<head>
	<title>Online Chat System</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="custom-background">
	<div class="jumbotron">
		<div class="container">