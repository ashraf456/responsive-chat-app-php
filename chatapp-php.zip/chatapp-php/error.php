<?php
include 'header.php'
?>
<div style="padding:20%; font-size: 50px;">Please Try Again Carefully<div><button class="btn btn-danger"><a href="index.php">Go To Home</a></button></div></div>