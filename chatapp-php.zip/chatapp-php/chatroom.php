<?php 
include 'header.php';
include 'session.php';
include 'db.php';
 ?>
				<div class="form-body">
					<h1>ChatRoom</h1>
						<p>Start Chat with your Friends</p>
					<div class="chat-box">
						<div class="user-masseges">
							<h3 class="user-online"><?php echo $_SESSION['username']; ?>: _Online</span></h3>
							<div class="chat-messages">
								<?php
					                $sql = "SELECT * FROM chat";
					                $result =$conn->query($sql);
					            if($result->num_rows > 0){
					                while ($row = $result->fetch_assoc())
					                {
					                	$username = $row['username'];
					                    $message = $row['message'];
					                    $datetime = $row['datetime'];
								?>
					            <div class="all-messages">
					            	<ul>
					            		<div class="col-xs-4"  style="border-right:1px solid lightgray;"><li>USER: <span style="font-weight: bold; color:gold;"><?php echo $username; ?></span></li></div>
					            		<div class="col-xs-4"  style="border-right:1px solid lightgray;"	><li style="font-weight: bold; color: chocolate;"><?php echo $message; ?></li></div>
					            		<div class="col-xs-4"><li style="color:skyblue;"><?php echo $datetime; ?></li></div>
					            	</ul>
					            </div>


					            <?php
					            } }
					            ?>
							</div>
							<div class="chat-form">
								<form action="send.php" method="post">
									<div class="form-group">
										<label style="width:100%;" for="message">
										<textarea type="text" placeholder="Your Message" name="message" class="form-control" required></textarea></label>
										<br>
									    <button type="submit" name="submit" class="btn btn-success">Send</button>
									  </div>
								</form>
							</div>
						</div>
					</div>
				</div>
					<br>
					<form action="logout.php" style="margin: 0 auto;">
						<div class="form-group">
							<label style="float: left; text-align: center;" for="username">You can Logout Here<br>
							<input type="submit" value="LOGOUT" name="username" class="btn btn-success" required></label>
					</form>