<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "chatroom";
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// if($conn){
// 	echo "Connecteion Created";
// }else{
// 	die("Connection Failed" .mysqli_errno($conn));
// }

 ?>