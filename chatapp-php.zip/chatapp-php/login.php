<?php 
session_start();
include 'header.php';
include 'db.php';
?>
<?php
$username = $_POST['username'];
$password = $_POST['password'];
$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result=$conn->query($sql);
        if(!$row=$result->fetch_assoc()){
            header("Location:error.php");      
        }else{
        	$_SESSION['username']=$_POST['username'];
            header("Location:chatroom.php");
        }
?>