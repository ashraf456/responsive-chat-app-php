<?php 
include 'db.php';
include 'header.php';
 ?>
 <?php
            if(isset($_POST['submit'])){
                $username = $_POST['username'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $country = $_POST['country'];
                // $image = $_FILES['image']['name'];
                // $post_image_temp = $_FILES['image']['tmp_name'];
                //     move_uploaded_file($post_image_temp, "../images/$image");

                    $query = "INSERT INTO users(username,email,password,country)";
                    $query .= "VALUES('$username','$email','$password','$country')";
                    $create_post_query = mysqli_query($conn, $query);
                    if(!$create_post_query){
                    die('QUERY ERROR' . mysqli_error($conn));      
                            }
                        }
        ?>
			<div class="chatroom-intro">
				<h1>Welcome to <strong>PAKTRICK</strong> Online Chat System</h1><br>
				<p>By using this chat system your will able to do chat with your friends and family. I hope your will really enjoy it</p><br>
				<strong>Thank You</strong><br><br>
			</div>
			<div class="form-body">
				<form method="post" action="login.php">
					<div class="form-group">
						<label for="username">User Name:
						<input type="text" name="username" class="form-control"></label>
					</div>
					<div class="form-group">
						<label for="password">Password:
						<input type="password" name="password" class="form-control"></label>
					</div>
					<div class="col-lg-12">
						<div>
							<button type="submit" name="submit" id="sign-in" class="btn btn-danger">Signin</button>
						</div>
						<br><p style="color: gold;"><strong>If not Registered, thek click to Register</strong></p>
							<button type="button" id="sign-up" class="btn btn-success"><a href="sign-up.php">Register</a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>
